import { Github, Linkedin, Mail, Phone } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-card border-t border-border mt-20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold text-accent mb-4">Vamsi</h3>
            <p className="text-muted-foreground text-sm">
              Cloud & Data Engineer passionate about building scalable systems and intelligent data solutions.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <div className="flex flex-col gap-2">
              <Link to="/about" className="text-sm text-muted-foreground hover:text-accent transition-colors">About</Link>
              <Link to="/projects" className="text-sm text-muted-foreground hover:text-accent transition-colors">Projects</Link>
              <Link to="/experience" className="text-sm text-muted-foreground hover:text-accent transition-colors">Experience</Link>
              <Link to="/contact" className="text-sm text-muted-foreground hover:text-accent transition-colors">Contact</Link>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Connect</h4>
            <div className="flex gap-4">
              <a href="https://linkedin.com/in/vamsi" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="https://github.com/vamsi" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent transition-colors">
                <Github size={20} />
              </a>
              <a href="mailto:vamsi@email.com" className="text-muted-foreground hover:text-accent transition-colors">
                <Mail size={20} />
              </a>
              <a href="tel:+1234567890" className="text-muted-foreground hover:text-accent transition-colors">
                <Phone size={20} />
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-border mt-8 pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Vamsi. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
