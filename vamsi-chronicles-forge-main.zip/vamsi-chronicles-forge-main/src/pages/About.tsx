import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Award, Briefcase, GraduationCap } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4 max-w-4xl">
        <h1 className="text-4xl md:text-5xl font-bold mb-8 animate-fade-in-up text-accent">
          About Me
        </h1>
        
        <div className="prose prose-invert max-w-none">
          <div className="mb-12 animate-fade-in-up [animation-delay:200ms]">
            <p className="text-lg text-foreground/90 mb-6 leading-relaxed">
              With over 4 years of hands-on experience at Capgemini, I've dedicated my career to solving real-world challenges 
              in cloud infrastructure, enterprise SAP systems, and data engineering. My work has spanned critical sectors including 
              banking, finance, and enterprise resource planning, where I've built and optimized systems that handle millions of 
              transactions and power business-critical decisions.
            </p>
            
            <p className="text-lg text-foreground/90 mb-6 leading-relaxed">
              Currently pursuing my Master's degree in Computer Technology at Eastern Illinois University (2023-2025), I'm 
              deepening my expertise in advanced computing concepts while maintaining a strong connection to industry practices. 
              This combination of extensive professional experience and academic rigor gives me a unique perspective on building 
              solutions that are both theoretically sound and practically effective.
            </p>
            
            <p className="text-lg text-foreground/90 mb-8 leading-relaxed">
              My passion lies in architecting resilient, scalable systems that empower teams to innovate faster and deliver value 
              with confidence. Whether it's automating infrastructure provisioning, building real-time data pipelines, or optimizing 
              enterprise SAP workflows, I bring a combination of technical depth, automation mindset, and collaborative spirit to 
              every project. I'm actively seeking opportunities in AWS Cloud Engineering, DevOps, and Data Engineering where I can 
              continue to drive innovation and operational excellence.
            </p>
          </div>

          {/* Core Values */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="bg-card p-6 rounded-lg border border-border hover:border-accent transition-all animate-fade-in">
              <Award className="text-accent mb-4" size={32} />
              <h3 className="text-xl font-bold mb-2">Excellence</h3>
              <p className="text-muted-foreground">
                Committed to delivering high-quality solutions that exceed expectations
              </p>
            </div>
            
            <div className="bg-card p-6 rounded-lg border border-border hover:border-accent transition-all animate-fade-in [animation-delay:100ms]">
              <Briefcase className="text-accent mb-4" size={32} />
              <h3 className="text-xl font-bold mb-2">Innovation</h3>
              <p className="text-muted-foreground">
                Constantly exploring new technologies and methodologies to solve complex problems
              </p>
            </div>
            
            <div className="bg-card p-6 rounded-lg border border-border hover:border-accent transition-all animate-fade-in [animation-delay:200ms]">
              <GraduationCap className="text-accent mb-4" size={32} />
              <h3 className="text-xl font-bold mb-2">Growth</h3>
              <p className="text-muted-foreground">
                Dedicated to continuous learning and sharing knowledge with the community
              </p>
            </div>
          </div>

          {/* Mission Statement */}
          <div className="bg-gradient-to-r from-accent/10 to-transparent p-8 rounded-lg border-l-4 border-accent mb-12 animate-fade-in">
            <p className="text-xl font-semibold text-foreground italic">
              "Architect resilient, scalable systems that empower teams to innovate faster and deliver value with confidence."
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 animate-fade-in">
            <Link to="/projects">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 w-full sm:w-auto">
                View My Work
              </Button>
            </Link>
            <a href="/resume.pdf" download>
              <Button size="lg" variant="outline" className="border-accent text-accent hover:bg-accent hover:text-accent-foreground w-full sm:w-auto">
                Download My Resume
              </Button>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
