import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Mail, Linkedin, Github, Phone, MapPin, Send } from "lucide-react";

const Contact = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Create mailto link
    const mailtoLink = `mailto:vamsi@email.com?subject=Portfolio Contact from ${formData.name}&body=${encodeURIComponent(
      `Name: ${formData.name}\nEmail: ${formData.email}\n\nMessage:\n${formData.message}`
    )}`;
    
    window.location.href = mailtoLink;
    
    toast({
      title: "Opening email client",
      description: "Your default email client will open with the message pre-filled.",
    });

    setFormData({ name: "", email: "", message: "" });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4 max-w-5xl">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 animate-fade-in-up text-accent">
            Let's Connect
          </h1>
          <p className="text-lg text-foreground/90 animate-fade-in-up [animation-delay:200ms]">
            I'm currently seeking new opportunities in Cloud Engineering, DevOps, and Data Engineering.
          </p>
          <p className="text-lg text-muted-foreground animate-fade-in-up [animation-delay:300ms]">
            Feel free to reach out — I'd love to hear from you!
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Contact Form */}
          <Card className="bg-card border-border animate-fade-in">
            <CardHeader>
              <CardTitle className="text-2xl text-accent">Send a Message</CardTitle>
              <CardDescription>Fill out the form below and I'll get back to you soon</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="text-sm font-medium mb-2 block">
                    Name
                  </label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="bg-background border-border focus:border-accent"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="text-sm font-medium mb-2 block">
                    Email
                  </label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="bg-background border-border focus:border-accent"
                    placeholder="your.email@example.com"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="text-sm font-medium mb-2 block">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    className="bg-background border-border focus:border-accent min-h-[150px]"
                    placeholder="Tell me about your project or opportunity..."
                  />
                </div>
                <Button type="submit" className="w-full bg-accent text-accent-foreground hover:bg-accent/90">
                  <Send size={18} className="mr-2" />
                  Send Message
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-6 animate-fade-in [animation-delay:100ms]">
            <Card className="bg-card border-border hover:border-accent transition-all">
              <CardHeader>
                <CardTitle className="text-2xl text-accent">Contact Information</CardTitle>
                <CardDescription>Reach out through any of these channels</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <a 
                  href="mailto:vamsi@email.com" 
                  className="flex items-center gap-3 text-foreground/90 hover:text-accent transition-colors group"
                >
                  <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                    <Mail className="text-accent" size={20} />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Email</div>
                    <div className="font-medium">vamsi@email.com</div>
                  </div>
                </a>

                <a 
                  href="tel:+1234567890" 
                  className="flex items-center gap-3 text-foreground/90 hover:text-accent transition-colors group"
                >
                  <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                    <Phone className="text-accent" size={20} />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Phone</div>
                    <div className="font-medium">+1 (234) 567-8900</div>
                  </div>
                </a>

                <div className="flex items-center gap-3 text-foreground/90">
                  <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
                    <MapPin className="text-accent" size={20} />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Location</div>
                    <div className="font-medium">Charleston, Illinois, USA</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border hover:border-accent transition-all">
              <CardHeader>
                <CardTitle className="text-xl text-accent">Connect on Social</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  <a
                    href="https://linkedin.com/in/vamsi"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex flex-col items-center gap-2 p-4 bg-accent/10 rounded-lg hover:bg-accent/20 transition-all group"
                  >
                    <Linkedin className="text-accent" size={24} />
                    <span className="text-xs font-medium">LinkedIn</span>
                  </a>
                  <a
                    href="https://github.com/vamsi"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex flex-col items-center gap-2 p-4 bg-accent/10 rounded-lg hover:bg-accent/20 transition-all group"
                  >
                    <Github className="text-accent" size={24} />
                    <span className="text-xs font-medium">GitHub</span>
                  </a>
                  <a
                    href="mailto:vamsi@email.com"
                    className="flex flex-col items-center gap-2 p-4 bg-accent/10 rounded-lg hover:bg-accent/20 transition-all group"
                  >
                    <Mail className="text-accent" size={24} />
                    <span className="text-xs font-medium">Email</span>
                  </a>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-accent/10 to-transparent border-accent/50">
              <CardContent className="pt-6">
                <p className="text-foreground/90 italic text-center">
                  "Looking forward to discussing how I can contribute to your team's success through cloud engineering, 
                  DevOps automation, and data-driven solutions."
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
