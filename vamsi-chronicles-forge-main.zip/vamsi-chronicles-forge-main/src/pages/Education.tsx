import { Badge } from "@/components/ui/badge";
import { GraduationCap, Award, Code2 } from "lucide-react";

const Education = () => {
  const skills = {
    technical: ["Python", "SQL", "SAP ABAP", "HTML", "JavaScript", "Shell scripting"],
    cloud: ["AWS EC2", "VPC", "S3", "RDS", "Lambda", "API Gateway", "IAM", "EKS", "Terraform", "CloudFormation"],
    devops: ["Jenkins", "Docker", "Helm", "GitLab CI/CD", "Prometheus", "Grafana", "CloudWatch", "Splunk"],
    sap: ["CDS Views", "ALV", "SmartForms", "BAPIs", "OData", "ECC", "S/4HANA", "Fiori"],
    tools: ["Linux", "Jira", "Git"],
    methodologies: ["Agile", "Scrum"],
  };

  const certifications = [
    "AWS Certified Cloud Practitioner",
    "SAP ABAP NetWeaver 7.5",
    "Terraform Associate",
    "Pega Certified System Architect",
  ];

  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4 max-w-5xl">
        <h1 className="text-4xl md:text-5xl font-bold mb-8 animate-fade-in-up text-accent">
          Education & Skills
        </h1>

        {/* Education Section */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 flex items-center">
            <GraduationCap className="mr-3 text-accent" size={32} />
            Education
          </h2>

          <div className="space-y-8">
            {/* Master's Degree */}
            <div className="bg-card p-6 rounded-lg border border-border hover:border-accent transition-all animate-fade-in">
              <div className="flex items-start justify-between flex-wrap gap-4 mb-4">
                <div>
                  <h3 className="text-2xl font-bold text-accent mb-2">Master's in Computer Technology</h3>
                  <p className="text-lg font-semibold">Eastern Illinois University</p>
                  <p className="text-muted-foreground">Charleston, Illinois, USA</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold">2023 – 2025</p>
                </div>
              </div>
              <div className="bg-accent/10 p-4 rounded-lg border-l-4 border-accent mt-4">
                <p className="font-semibold mb-2">Highlighted Research:</p>
                <p className="text-foreground/90">
                  IoT-Based Coal Mine Safety Monitoring System (Published in peer-reviewed journal)
                </p>
              </div>
            </div>

            {/* Bachelor's Degree */}
            <div className="bg-card p-6 rounded-lg border border-border hover:border-accent transition-all animate-fade-in [animation-delay:100ms]">
              <div className="flex items-start justify-between flex-wrap gap-4 mb-4">
                <div>
                  <h3 className="text-2xl font-bold text-accent mb-2">Bachelor's in Electronics & Communications Engineering</h3>
                  <p className="text-lg font-semibold">KL University</p>
                  <p className="text-muted-foreground">Guntur, Andhra Pradesh, India</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold">2016 – 2020</p>
                </div>
              </div>
              <p className="text-foreground/90 mt-4">
                Strong foundation in electronics, signal processing, and embedded systems development
              </p>
            </div>
          </div>
        </section>

        {/* Certifications Section */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 flex items-center">
            <Award className="mr-3 text-accent" size={32} />
            Certifications
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {certifications.map((cert, index) => (
              <div 
                key={cert} 
                className="bg-card p-4 rounded-lg border border-border hover:border-accent transition-all animate-fade-in flex items-center"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <Award className="text-accent mr-3 flex-shrink-0" size={20} />
                <span className="font-medium">{cert}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Skills Section */}
        <section>
          <h2 className="text-3xl font-bold mb-8 flex items-center">
            <Code2 className="mr-3 text-accent" size={32} />
            Technical Skills
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-card p-6 rounded-lg border border-border hover:border-accent transition-all animate-fade-in">
              <h3 className="text-xl font-bold mb-4 text-accent">Programming & Scripting</h3>
              <div className="flex flex-wrap gap-2">
                {skills.technical.map((skill) => (
                  <Badge key={skill} variant="outline" className="border-accent/50 text-accent/90">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="bg-card p-6 rounded-lg border border-border hover:border-accent transition-all animate-fade-in [animation-delay:50ms]">
              <h3 className="text-xl font-bold mb-4 text-accent">Cloud Technologies (AWS)</h3>
              <div className="flex flex-wrap gap-2">
                {skills.cloud.map((skill) => (
                  <Badge key={skill} variant="outline" className="border-accent/50 text-accent/90">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="bg-card p-6 rounded-lg border border-border hover:border-accent transition-all animate-fade-in [animation-delay:100ms]">
              <h3 className="text-xl font-bold mb-4 text-accent">DevOps & Monitoring</h3>
              <div className="flex flex-wrap gap-2">
                {skills.devops.map((skill) => (
                  <Badge key={skill} variant="outline" className="border-accent/50 text-accent/90">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="bg-card p-6 rounded-lg border border-border hover:border-accent transition-all animate-fade-in [animation-delay:150ms]">
              <h3 className="text-xl font-bold mb-4 text-accent">SAP Development</h3>
              <div className="flex flex-wrap gap-2">
                {skills.sap.map((skill) => (
                  <Badge key={skill} variant="outline" className="border-accent/50 text-accent/90">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="bg-card p-6 rounded-lg border border-border hover:border-accent transition-all animate-fade-in [animation-delay:200ms]">
              <h3 className="text-xl font-bold mb-4 text-accent">Tools & Platforms</h3>
              <div className="flex flex-wrap gap-2">
                {skills.tools.map((skill) => (
                  <Badge key={skill} variant="outline" className="border-accent/50 text-accent/90">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="bg-card p-6 rounded-lg border border-border hover:border-accent transition-all animate-fade-in [animation-delay:250ms]">
              <h3 className="text-xl font-bold mb-4 text-accent">Methodologies</h3>
              <div className="flex flex-wrap gap-2">
                {skills.methodologies.map((skill) => (
                  <Badge key={skill} variant="outline" className="border-accent/50 text-accent/90">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Education;
