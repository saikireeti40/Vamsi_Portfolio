import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Building2, Calendar, ExternalLink } from "lucide-react";

const Experience = () => {
  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4 max-w-4xl">
        <h1 className="text-4xl md:text-5xl font-bold mb-8 animate-fade-in-up text-accent">
          Work Experience
        </h1>
        <p className="text-lg text-muted-foreground mb-12 animate-fade-in-up [animation-delay:200ms]">
          4+ years of professional experience building cloud infrastructure, data pipelines, and enterprise SAP solutions.
        </p>

        <div className="space-y-12">
          {/* Cloud & Data Engineer Role */}
          <div className="relative pl-8 border-l-2 border-accent/50 animate-fade-in">
            <div className="absolute left-0 top-0 w-4 h-4 bg-accent rounded-full -translate-x-[9px]"></div>
            
            <div className="mb-4">
              <div className="flex items-start justify-between flex-wrap gap-2 mb-2">
                <h2 className="text-2xl font-bold text-accent">Cloud & Data Engineer</h2>
                <div className="flex items-center text-muted-foreground text-sm">
                  <Calendar size={16} className="mr-2" />
                  June 2021 – March 2023
                </div>
              </div>
              <div className="flex items-center text-foreground/80 mb-4">
                <Building2 size={18} className="mr-2 text-accent" />
                <span className="font-semibold">Capgemini</span>
              </div>
            </div>

            <p className="text-foreground/90 mb-4 leading-relaxed">
              Specialized in building and maintaining cloud infrastructure and data pipelines for banking and financial 
              services clients. Led initiatives in infrastructure automation, CI/CD implementation, and cloud-native 
              application deployment.
            </p>

            <div className="mb-4">
              <h3 className="font-semibold mb-3">Key Responsibilities:</h3>
              <ul className="space-y-2 text-foreground/90">
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Architected AWS infrastructure using Terraform and CloudFormation for automated provisioning</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Built CI/CD pipelines with Jenkins and GitLab CI/CD, implementing blue/green and canary deployments</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Migrated applications to containerized microservices using Docker and Amazon EKS</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Developed Python-based ETL pipelines for data warehousing on AWS Redshift</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Established monitoring with CloudWatch, Prometheus, and Grafana for 99.9% uptime</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Collaborated with DevSecOps teams to integrate security scanning and compliance checks</span>
                </li>
              </ul>
            </div>

            <div className="mb-4">
              <h3 className="font-semibold mb-3">Featured Projects:</h3>
              <div className="flex flex-col gap-2">
                <Link to="/projects/cloud-infrastructure" className="text-accent hover:underline flex items-center">
                  Cloud Infrastructure for Financial Apps
                  <ExternalLink size={14} className="ml-1" />
                </Link>
                <Link to="/projects/data-analytics" className="text-accent hover:underline flex items-center">
                  Cloud-Based Data Analytics Platform
                  <ExternalLink size={14} className="ml-1" />
                </Link>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3">Technologies:</h3>
              <div className="flex flex-wrap gap-2">
                {["AWS", "Terraform", "Jenkins", "Docker", "Python", "Kubernetes", "Redshift", "CloudWatch"].map((tech) => (
                  <Badge key={tech} variant="outline" className="border-accent/50 text-accent/90">
                    {tech}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          {/* SAP ABAP Developer Role */}
          <div className="relative pl-8 border-l-2 border-accent/50 animate-fade-in [animation-delay:200ms]">
            <div className="absolute left-0 top-0 w-4 h-4 bg-accent rounded-full -translate-x-[9px]"></div>
            
            <div className="mb-4">
              <div className="flex items-start justify-between flex-wrap gap-2 mb-2">
                <h2 className="text-2xl font-bold text-accent">SAP ABAP Developer</h2>
                <div className="flex items-center text-muted-foreground text-sm">
                  <Calendar size={16} className="mr-2" />
                  June 2021 – March 2023
                </div>
              </div>
              <div className="flex items-center text-foreground/80 mb-4">
                <Building2 size={18} className="mr-2 text-accent" />
                <span className="font-semibold">Capgemini</span>
              </div>
            </div>

            <p className="text-foreground/90 mb-4 leading-relaxed">
              Developed enterprise SAP solutions for financial services clients, focusing on automating finance processes 
              and building integrations between SAP and third-party systems. Worked extensively with both SAP ECC and 
              S/4HANA platforms.
            </p>

            <div className="mb-4">
              <h3 className="font-semibold mb-3">Key Responsibilities:</h3>
              <ul className="space-y-2 text-foreground/90">
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Developed custom ABAP programs, reports, and enhancements for SAP ECC and S/4HANA</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Created optimized CDS Views and AMDP for HANA database performance</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Built OData services for SAP Fiori applications and external integrations</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Implemented ALV reports, SmartForms, and Adobe Forms for financial documentation</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Designed BAPIs and RFC-enabled function modules for system integrations</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Achieved zero production defects through comprehensive testing and quality assurance</span>
                </li>
              </ul>
            </div>

            <div className="mb-4">
              <h3 className="font-semibold mb-3">Featured Project:</h3>
              <Link to="/projects/sap-abap" className="text-accent hover:underline flex items-center">
                SAP ABAP & S/4HANA Finance Automation
                <ExternalLink size={14} className="ml-1" />
              </Link>
            </div>

            <div>
              <h3 className="font-semibold mb-3">Technologies:</h3>
              <div className="flex flex-wrap gap-2">
                {["SAP ABAP", "S/4HANA", "CDS Views", "OData", "Fiori", "HANA SQL", "BAPIs", "ALV"].map((tech) => (
                  <Badge key={tech} variant="outline" className="border-accent/50 text-accent/90">
                    {tech}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          {/* Testimonial */}
          <div className="bg-card p-8 rounded-lg border-l-4 border-accent animate-fade-in [animation-delay:400ms]">
            <p className="text-foreground/90 italic mb-4 text-lg">
              "Working with Vamsi on our banking and finance platforms was exceptional. He consistently delivered 
              sprint-based results, fostering strong collaboration with DevSecOps teams and minimizing defects through 
              rigorous API testing."
            </p>
            <p className="text-accent font-semibold">— Project Manager, Capgemini</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Experience;
