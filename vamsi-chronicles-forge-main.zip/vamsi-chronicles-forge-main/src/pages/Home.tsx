import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Cloud, Database, Code2 } from "lucide-react";
import heroBackground from "@/assets/hero-background.jpg";

const Home = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section 
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.8)), url(${heroBackground})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundAttachment: "fixed",
        }}
      >
        <div className="container mx-auto px-4 text-center z-10">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fade-in-up bg-gradient-gold bg-clip-text text-transparent">
            Vamsi
          </h1>
          <p className="text-xl md:text-2xl text-foreground/90 mb-4 animate-fade-in-up [animation-delay:200ms]">
            Cloud & Data Engineer | AWS | DevOps | SAP | Analytics
          </p>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto animate-fade-in-up [animation-delay:400ms]">
            I build scalable cloud systems and data pipelines that power intelligent decisions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up [animation-delay:600ms]">
            <Link to="/projects">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 group">
                View My Work
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
              </Button>
            </Link>
            <a href="/resume.pdf" download>
              <Button size="lg" variant="outline" className="border-accent text-accent hover:bg-accent hover:text-accent-foreground">
                Download Resume
              </Button>
            </a>
            <Link to="/contact">
              <Button size="lg" variant="outline" className="border-foreground/30 hover:border-accent hover:text-accent">
                Contact Me
              </Button>
            </Link>
          </div>
        </div>
        
        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-accent rounded-full flex items-start justify-center p-2">
            <div className="w-1 h-3 bg-accent rounded-full"></div>
          </div>
        </div>
      </section>

      {/* Quick Overview Section */}
      <section className="py-20 bg-card/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-background/50 rounded-lg border border-border hover:border-accent transition-all hover:shadow-elegant animate-fade-in">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Cloud className="text-accent" size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">Cloud Infrastructure</h3>
              <p className="text-muted-foreground">
                AWS certified with expertise in EC2, VPC, S3, Lambda, and infrastructure automation using Terraform
              </p>
            </div>
            
            <div className="text-center p-6 bg-background/50 rounded-lg border border-border hover:border-accent transition-all hover:shadow-elegant animate-fade-in [animation-delay:200ms]">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Database className="text-accent" size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">Data Engineering</h3>
              <p className="text-muted-foreground">
                Building robust data pipelines with AWS Redshift, Python, SQL, and real-time analytics solutions
              </p>
            </div>
            
            <div className="text-center p-6 bg-background/50 rounded-lg border border-border hover:border-accent transition-all hover:shadow-elegant animate-fade-in [animation-delay:400ms]">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Code2 className="text-accent" size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">DevOps & SAP</h3>
              <p className="text-muted-foreground">
                CI/CD pipeline automation with Jenkins, Docker, and SAP ABAP development for enterprise solutions
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Stats */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="animate-fade-in">
              <div className="text-4xl md:text-5xl font-bold text-accent mb-2">4+</div>
              <div className="text-muted-foreground">Years Experience</div>
            </div>
            <div className="animate-fade-in [animation-delay:100ms]">
              <div className="text-4xl md:text-5xl font-bold text-accent mb-2">10+</div>
              <div className="text-muted-foreground">Major Projects</div>
            </div>
            <div className="animate-fade-in [animation-delay:200ms]">
              <div className="text-4xl md:text-5xl font-bold text-accent mb-2">5</div>
              <div className="text-muted-foreground">Certifications</div>
            </div>
            <div className="animate-fade-in [animation-delay:300ms]">
              <div className="text-4xl md:text-5xl font-bold text-accent mb-2">1</div>
              <div className="text-muted-foreground">Publication</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
