import { Link } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Cloud, Code, Database } from "lucide-react";

const Projects = () => {
  const projects = [
    {
      id: "cloud-infrastructure",
      title: "Cloud Infrastructure for Financial Apps",
      description: "Automated infrastructure provisioning and CI/CD pipelines for banking applications handling millions of transactions",
      icon: Cloud,
      tags: ["AWS", "Terraform", "Jenkins", "Docker", "Python"],
      outcomes: ["40% faster deployments", "99.9% uptime", "50% cost reduction"],
    },
    {
      id: "sap-abap",
      title: "SAP ABAP & S/4HANA Finance Automation",
      description: "Enterprise-scale SAP solutions automating financial processes and third-party integrations",
      icon: Code,
      tags: ["SAP ABAP", "CDS Views", "OData", "HANA SQL", "Fiori"],
      outcomes: ["60% reduction in manual processing", "Zero defects in production", "Enhanced reporting accuracy"],
    },
    {
      id: "data-analytics",
      title: "Cloud-Based Data Analytics Platform",
      description: "Real-time data pipeline processing terabytes of data for business intelligence and predictive analytics",
      icon: Database,
      tags: ["AWS Redshift", "Python", "SQL", "Docker", "ETL"],
      outcomes: ["Real-time analytics", "Scalable architecture", "Data-driven insights"],
    },
  ];

  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 animate-fade-in-up text-accent">
            Featured Projects
          </h1>
          <p className="text-lg text-muted-foreground animate-fade-in-up [animation-delay:200ms]">
            A selection of my most impactful work in cloud infrastructure, enterprise software, and data engineering.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => {
            const Icon = project.icon;
            return (
              <Link 
                key={project.id} 
                to={`/projects/${project.id}`}
                className="group"
              >
                <Card 
                  className="h-full border-border hover:border-accent transition-all duration-300 hover:shadow-elegant animate-fade-in bg-card/50 backdrop-blur-sm"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <CardHeader>
                    <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                      <Icon className="text-accent" size={24} />
                    </div>
                    <CardTitle className="group-hover:text-accent transition-colors">
                      {project.title}
                    </CardTitle>
                    <CardDescription className="text-muted-foreground">
                      {project.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="border-accent/50 text-accent/90">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <div className="space-y-2 mb-4">
                      {project.outcomes.map((outcome, i) => (
                        <div key={i} className="text-sm text-muted-foreground flex items-start">
                          <span className="text-accent mr-2">•</span>
                          {outcome}
                        </div>
                      ))}
                    </div>
                    <div className="flex items-center text-accent group-hover:translate-x-2 transition-transform">
                      <span className="text-sm font-medium">Read Case Study</span>
                      <ArrowRight size={16} className="ml-2" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Projects;
