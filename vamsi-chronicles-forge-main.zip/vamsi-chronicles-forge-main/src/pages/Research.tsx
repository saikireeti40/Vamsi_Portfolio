import { Badge } from "@/components/ui/badge";
import { BookOpen, ExternalLink, Users, Target } from "lucide-react";

const Research = () => {
  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4 max-w-4xl">
        <h1 className="text-4xl md:text-5xl font-bold mb-8 animate-fade-in-up text-accent">
          Research & Publications
        </h1>
        <p className="text-lg text-muted-foreground mb-12 animate-fade-in-up [animation-delay:200ms]">
          Academic research focused on IoT systems and real-time monitoring solutions for critical environments.
        </p>

        <div className="bg-card rounded-lg border border-border hover:border-accent transition-all p-8 animate-fade-in">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-16 h-16 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
              <BookOpen className="text-accent" size={32} />
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-2 text-accent">
                IoT-Based Coal Mine Safety Monitoring and Alerting System
              </h2>
              <div className="flex flex-wrap gap-2 mb-4">
                <Badge variant="outline" className="border-accent/50 text-accent/90">
                  Published
                </Badge>
                <Badge variant="outline" className="border-accent/50 text-accent/90">
                  Peer-Reviewed
                </Badge>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="font-semibold mb-2 flex items-center">
                <Target className="text-accent mr-2" size={20} />
                Research Overview
              </h3>
              <p className="text-foreground/90 leading-relaxed">
                Developed an innovative IoT-based safety monitoring system designed to enhance worker safety in coal 
                mining environments. The system uses a network of sensors to detect hazardous conditions such as toxic 
                gas accumulation, temperature spikes, and structural instabilities, providing real-time alerts to prevent 
                accidents and save lives.
              </p>
            </div>

            <div className="bg-accent/10 p-6 rounded-lg border-l-4 border-accent">
              <h3 className="font-semibold mb-3">Key Contributions</h3>
              <ul className="space-y-2 text-foreground/90">
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Designed and implemented multi-sensor IoT architecture for hazard detection</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Developed Arduino-based data collection and processing system</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Created Python-based cloud messaging platform for real-time alerts</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Implemented automated notification system for emergency response teams</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-3 flex items-center">
                <Users className="text-accent mr-2" size={20} />
                Role & Responsibilities
              </h3>
              <p className="text-foreground/90 mb-3">
                <strong>Position:</strong> IoT Developer / Researcher
              </p>
              <ul className="space-y-2 text-foreground/90">
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Led the technical design and implementation of the IoT sensor network</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Programmed microcontroller systems for data acquisition and processing</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Developed cloud-based alert distribution system using Python</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Conducted field testing and system calibration</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Authored research paper and presented findings</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-3">Technologies Used</h3>
              <div className="flex flex-wrap gap-2">
                {["IoT Sensors", "Arduino", "Python", "Cloud Messaging", "Embedded Systems", "Real-time Processing"].map((tech) => (
                  <Badge key={tech} variant="outline" className="border-accent/50 text-accent/90">
                    {tech}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="bg-card p-6 rounded-lg border border-border">
              <h3 className="font-semibold mb-3">Impact & Outcomes</h3>
              <ul className="space-y-2 text-foreground/90">
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Published in peer-reviewed academic journal</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Demonstrated significant improvement in mining safety through real-time hazard detection</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Reduced emergency response time through automated alerting mechanisms</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Created scalable IoT framework applicable to other industrial safety scenarios</span>
                </li>
              </ul>
            </div>

            <div className="border-t border-border pt-6">
              <p className="text-sm text-muted-foreground italic">
                This research demonstrates my ability to apply IoT and cloud technologies to solve real-world safety 
                challenges, combining embedded systems development with cloud-based data processing and alert systems.
              </p>
            </div>
          </div>
        </div>

        {/* Additional Research Interests */}
        <div className="mt-12 bg-gradient-to-r from-accent/10 to-transparent p-8 rounded-lg border-l-4 border-accent animate-fade-in [animation-delay:200ms]">
          <h2 className="text-2xl font-bold mb-4">Research Interests</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="font-semibold mb-2 text-accent">Cloud-Native Systems</h3>
              <p className="text-sm text-foreground/80">
                Scalable architectures, microservices, and serverless computing
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2 text-accent">Data Engineering</h3>
              <p className="text-sm text-foreground/80">
                Real-time data pipelines, stream processing, and analytics
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2 text-accent">IoT & Edge Computing</h3>
              <p className="text-sm text-foreground/80">
                Sensor networks, edge analytics, and distributed systems
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2 text-accent">DevOps Automation</h3>
              <p className="text-sm text-foreground/80">
                Infrastructure as code, CI/CD optimization, and deployment strategies
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Research;
