import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, ExternalLink } from "lucide-react";
import cloudTechBg from "@/assets/cloud-tech-bg.jpg";

const CloudInfrastructure = () => {
  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4 max-w-4xl">
        <Link to="/projects">
          <Button variant="ghost" className="mb-8 text-accent hover:text-accent/80">
            <ArrowLeft className="mr-2" size={16} />
            Back to Projects
          </Button>
        </Link>

        <div 
          className="relative h-64 md:h-96 rounded-lg mb-12 overflow-hidden"
          style={{
            backgroundImage: `linear-gradient(to bottom, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.7)), url(${cloudTechBg})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        >
          <div className="absolute inset-0 flex items-center justify-center">
            <h1 className="text-4xl md:text-5xl font-bold text-center text-accent">
              Cloud Infrastructure for Financial Apps
            </h1>
          </div>
        </div>

        <div className="prose prose-invert max-w-none">
          <div className="flex flex-wrap gap-2 mb-8">
            {["AWS", "Terraform", "Jenkins", "Docker", "Python", "EKS", "CloudWatch"].map((tag) => (
              <Badge key={tag} variant="outline" className="border-accent text-accent">
                {tag}
              </Badge>
            ))}
          </div>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Project Context</h2>
            <p className="text-foreground/90 leading-relaxed">
              Led the design and implementation of cloud infrastructure for critical banking and financial applications 
              at Capgemini, serving millions of users daily. This project involved building resilient, scalable systems 
              on AWS that could handle peak loads while maintaining strict security and compliance requirements.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Problem Statement</h2>
            <p className="text-foreground/90 leading-relaxed mb-4">
              The existing infrastructure was facing several critical challenges:
            </p>
            <ul className="list-disc list-inside space-y-2 text-foreground/90">
              <li>Manual provisioning processes leading to inconsistent environments</li>
              <li>Deployment cycles taking 2-3 days, hindering rapid feature delivery</li>
              <li>High operational costs due to inefficient resource utilization</li>
              <li>Limited monitoring and observability causing delayed incident response</li>
              <li>Difficulty maintaining compliance across multiple environments</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Role & Responsibilities</h2>
            <div className="bg-card p-6 rounded-lg border border-border">
              <p className="text-foreground/90 mb-4">
                <strong>Role:</strong> Cloud Infrastructure Engineer & DevOps Lead
              </p>
              <ul className="space-y-2 text-foreground/90">
                <li>• Architected AWS infrastructure using Terraform for infrastructure-as-code</li>
                <li>• Designed and implemented CI/CD pipelines using Jenkins and GitLab CI/CD</li>
                <li>• Led migration to containerized deployments using Docker and Amazon EKS</li>
                <li>• Established monitoring and alerting systems with CloudWatch, Prometheus, and Grafana</li>
                <li>• Collaborated with DevSecOps teams to integrate security scanning and compliance checks</li>
              </ul>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Tech Stack</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Cloud Platform</h3>
                <p className="text-sm text-muted-foreground">AWS (EC2, VPC, S3, RDS, Lambda, API Gateway, IAM, EKS)</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Infrastructure as Code</h3>
                <p className="text-sm text-muted-foreground">Terraform, CloudFormation</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">CI/CD</h3>
                <p className="text-sm text-muted-foreground">Jenkins, GitLab CI/CD, Helm</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Containerization</h3>
                <p className="text-sm text-muted-foreground">Docker, Kubernetes (EKS)</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Monitoring</h3>
                <p className="text-sm text-muted-foreground">CloudWatch, Prometheus, Grafana, Splunk</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Scripting</h3>
                <p className="text-sm text-muted-foreground">Python, Shell, Bash</p>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Process & Methods</h2>
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold mb-2">1. Infrastructure Design & Automation</h3>
                <p className="text-foreground/90">
                  Developed comprehensive Terraform modules for VPC, security groups, EC2 instances, RDS databases, 
                  and S3 buckets. Implemented infrastructure versioning and automated testing for all infrastructure changes.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">2. CI/CD Pipeline Implementation</h3>
                <p className="text-foreground/90">
                  Built Jenkins pipelines with automated testing, security scanning, and deployment stages. Integrated 
                  blue/green and canary deployment strategies to minimize downtime and risk.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">3. Container Orchestration</h3>
                <p className="text-foreground/90">
                  Migrated applications to containerized microservices architecture using Docker and deployed to Amazon EKS. 
                  Implemented Helm charts for application deployment and version management.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">4. Monitoring & Observability</h3>
                <p className="text-foreground/90">
                  Established comprehensive monitoring using CloudWatch for AWS resources, Prometheus for application metrics, 
                  and Grafana for visualization. Set up alerting rules and incident response workflows.
                </p>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Deliverables & Outcomes</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gradient-to-br from-accent/10 to-transparent p-6 rounded-lg border border-accent/50">
                <div className="text-3xl font-bold text-accent mb-2">40%</div>
                <p className="text-foreground/90">Faster deployment cycles (from days to hours)</p>
              </div>
              <div className="bg-gradient-to-br from-accent/10 to-transparent p-6 rounded-lg border border-accent/50">
                <div className="text-3xl font-bold text-accent mb-2">99.9%</div>
                <p className="text-foreground/90">Infrastructure uptime achieved</p>
              </div>
              <div className="bg-gradient-to-br from-accent/10 to-transparent p-6 rounded-lg border border-accent/50">
                <div className="text-3xl font-bold text-accent mb-2">50%</div>
                <p className="text-foreground/90">Reduction in operational costs</p>
              </div>
              <div className="bg-gradient-to-br from-accent/10 to-transparent p-6 rounded-lg border border-accent/50">
                <div className="text-3xl font-bold text-accent mb-2">100%</div>
                <p className="text-foreground/90">Infrastructure versioned and automated</p>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Testimonial</h2>
            <div className="bg-card p-6 rounded-lg border-l-4 border-accent italic">
              <p className="text-foreground/90 mb-4">
                "Working with Vamsi on our banking and finance platforms was exceptional. He consistently delivered 
                sprint-based results, fostering strong collaboration with DevSecOps teams and minimizing defects through 
                rigorous API testing."
              </p>
              <p className="text-sm text-muted-foreground">— Project Manager, Capgemini</p>
            </div>
          </section>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link to="/projects">
              <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
                View More Projects
              </Button>
            </Link>
            <Link to="/contact">
              <Button variant="outline" className="border-accent text-accent hover:bg-accent hover:text-accent-foreground">
                Discuss Your Project
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CloudInfrastructure;
