import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft } from "lucide-react";

const DataAnalytics = () => {
  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4 max-w-4xl">
        <Link to="/projects">
          <Button variant="ghost" className="mb-8 text-accent hover:text-accent/80">
            <ArrowLeft className="mr-2" size={16} />
            Back to Projects
          </Button>
        </Link>

        <h1 className="text-4xl md:text-5xl font-bold mb-8 text-accent">
          Cloud-Based Data Analytics Platform
        </h1>

        <div className="flex flex-wrap gap-2 mb-8">
          {["AWS Redshift", "Python", "SQL", "Docker", "ETL", "Lambda", "S3", "Apache Airflow"].map((tag) => (
            <Badge key={tag} variant="outline" className="border-accent text-accent">
              {tag}
            </Badge>
          ))}
        </div>

        <div className="prose prose-invert max-w-none">
          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Project Context</h2>
            <p className="text-foreground/90 leading-relaxed">
              Architected and deployed a comprehensive cloud-based data analytics platform at Capgemini, processing 
              terabytes of data daily to deliver real-time business intelligence and predictive analytics. The platform 
              served multiple business units across banking and financial services, enabling data-driven decision making 
              at scale.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Problem Statement</h2>
            <p className="text-foreground/90 leading-relaxed mb-4">
              The organization struggled with data silos and analytics challenges:
            </p>
            <ul className="list-disc list-inside space-y-2 text-foreground/90">
              <li>Data scattered across multiple legacy systems and databases</li>
              <li>Batch processing taking 12+ hours, preventing real-time insights</li>
              <li>Limited scalability during peak analysis periods</li>
              <li>Inconsistent data quality and transformation logic</li>
              <li>High infrastructure costs for on-premise analytics systems</li>
              <li>Difficulty in generating ad-hoc reports for business stakeholders</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Role & Responsibilities</h2>
            <div className="bg-card p-6 rounded-lg border border-border">
              <p className="text-foreground/90 mb-4">
                <strong>Role:</strong> Data Engineer & Platform Architect
              </p>
              <ul className="space-y-2 text-foreground/90">
                <li>• Designed end-to-end data pipeline architecture on AWS</li>
                <li>• Developed ETL workflows using Python and Apache Airflow</li>
                <li>• Implemented data warehouse on AWS Redshift with optimized schemas</li>
                <li>• Created serverless data processing functions using AWS Lambda</li>
                <li>• Built data quality frameworks and monitoring systems</li>
                <li>• Established data governance and security best practices</li>
              </ul>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Tech Stack</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Cloud Platform</h3>
                <p className="text-sm text-muted-foreground">AWS (Redshift, S3, Lambda, Glue, Athena)</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Data Processing</h3>
                <p className="text-sm text-muted-foreground">Python, Pandas, PySpark, SQL</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Orchestration</h3>
                <p className="text-sm text-muted-foreground">Apache Airflow, AWS Step Functions</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Containerization</h3>
                <p className="text-sm text-muted-foreground">Docker, Amazon ECS</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Analytics</h3>
                <p className="text-sm text-muted-foreground">SQL, Python, Tableau, QuickSight</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Monitoring</h3>
                <p className="text-sm text-muted-foreground">CloudWatch, DataDog, custom dashboards</p>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Process & Methods</h2>
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold mb-2">1. Data Ingestion Layer</h3>
                <p className="text-foreground/90">
                  Built scalable data ingestion pipelines using AWS Lambda and S3 for batch processing, and Kinesis 
                  for real-time streaming data. Implemented data validation and error handling at ingestion points.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">2. ETL Pipeline Development</h3>
                <p className="text-foreground/90">
                  Developed Python-based ETL jobs orchestrated by Apache Airflow, with containerized processing using 
                  Docker. Implemented incremental loading strategies to optimize processing time and costs.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">3. Data Warehouse Design</h3>
                <p className="text-foreground/90">
                  Architected AWS Redshift data warehouse with star schema design optimized for analytical queries. 
                  Implemented distribution keys, sort keys, and compression strategies for query performance.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">4. Analytics & Reporting</h3>
                <p className="text-foreground/90">
                  Created SQL-based analytical views and materialized tables for common reporting patterns. Integrated 
                  with Tableau and AWS QuickSight for business intelligence dashboards.
                </p>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Deliverables & Outcomes</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gradient-to-br from-accent/10 to-transparent p-6 rounded-lg border border-accent/50">
                <div className="text-3xl font-bold text-accent mb-2">Real-time</div>
                <p className="text-foreground/90">Data processing and analytics capabilities</p>
              </div>
              <div className="bg-gradient-to-br from-accent/10 to-transparent p-6 rounded-lg border border-accent/50">
                <div className="text-3xl font-bold text-accent mb-2">95%</div>
                <p className="text-foreground/90">Reduction in processing time (12hrs → 30min)</p>
              </div>
              <div className="bg-gradient-to-br from-accent/10 to-transparent p-6 rounded-lg border border-accent/50">
                <div className="text-3xl font-bold text-accent mb-2">10TB+</div>
                <p className="text-foreground/90">Data processed daily across pipelines</p>
              </div>
              <div className="bg-gradient-to-br from-accent/10 to-transparent p-6 rounded-lg border border-accent/50">
                <div className="text-3xl font-bold text-accent mb-2">99.9%</div>
                <p className="text-foreground/90">Data quality and pipeline reliability</p>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Key Achievements</h2>
            <ul className="space-y-3 text-foreground/90">
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>Built auto-scaling data pipelines that handled 3x traffic during peak periods</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>Implemented data lineage tracking and automated data quality checks</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>Reduced infrastructure costs by 45% through optimized resource utilization</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>Enabled self-service analytics for 200+ business users</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>Created reusable Python libraries for common data transformation patterns</span>
              </li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Technical Highlights</h2>
            <div className="bg-card p-6 rounded-lg border border-border">
              <ul className="space-y-3 text-foreground/90">
                <li>• Implemented Lambda-based event-driven architecture for real-time data processing</li>
                <li>• Created Docker containers for consistent ETL execution across environments</li>
                <li>• Developed custom Airflow operators for AWS service integrations</li>
                <li>• Built comprehensive monitoring dashboards tracking pipeline health and SLAs</li>
                <li>• Established CI/CD pipelines for automated testing and deployment of data jobs</li>
              </ul>
            </div>
          </section>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link to="/projects">
              <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
                View More Projects
              </Button>
            </Link>
            <Link to="/contact">
              <Button variant="outline" className="border-accent text-accent hover:bg-accent hover:text-accent-foreground">
                Discuss Your Project
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataAnalytics;
