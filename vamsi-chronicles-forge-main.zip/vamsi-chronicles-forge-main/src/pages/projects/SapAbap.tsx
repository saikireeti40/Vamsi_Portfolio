import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft } from "lucide-react";

const SapAbap = () => {
  return (
    <div className="min-h-screen py-20">
      <div className="container mx-auto px-4 max-w-4xl">
        <Link to="/projects">
          <Button variant="ghost" className="mb-8 text-accent hover:text-accent/80">
            <ArrowLeft className="mr-2" size={16} />
            Back to Projects
          </Button>
        </Link>

        <h1 className="text-4xl md:text-5xl font-bold mb-8 text-accent">
          SAP ABAP & S/4HANA Finance Automation
        </h1>

        <div className="flex flex-wrap gap-2 mb-8">
          {["SAP ABAP", "CDS Views", "OData", "HANA SQL", "Fiori", "ECC", "S/4HANA"].map((tag) => (
            <Badge key={tag} variant="outline" className="border-accent text-accent">
              {tag}
            </Badge>
          ))}
        </div>

        <div className="prose prose-invert max-w-none">
          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Project Context</h2>
            <p className="text-foreground/90 leading-relaxed">
              Developed enterprise-scale SAP ABAP solutions for financial services clients at Capgemini, focusing on 
              automating complex financial processes and integrating third-party systems. This project involved working 
              with both SAP ECC and S/4HANA systems, handling critical financial data for multinational corporations.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Problem Statement</h2>
            <p className="text-foreground/90 leading-relaxed mb-4">
              The finance department faced significant operational challenges:
            </p>
            <ul className="list-disc list-inside space-y-2 text-foreground/90">
              <li>Manual data entry and reconciliation processes consuming 60+ hours weekly</li>
              <li>Inconsistent reporting across different financial modules</li>
              <li>Lack of real-time visibility into financial operations</li>
              <li>Complex third-party integrations requiring manual intervention</li>
              <li>Limited mobile access to financial reports for decision-makers</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Role & Responsibilities</h2>
            <div className="bg-card p-6 rounded-lg border border-border">
              <p className="text-foreground/90 mb-4">
                <strong>Role:</strong> SAP ABAP Developer & Technical Lead
              </p>
              <ul className="space-y-2 text-foreground/90">
                <li>• Developed custom ABAP programs, reports, and enhancements for SAP ECC and S/4HANA</li>
                <li>• Created CDS Views and AMDP for optimized data retrieval from HANA database</li>
                <li>• Built OData services for SAP Fiori applications and third-party integrations</li>
                <li>• Implemented ALV reports, SmartForms, and Adobe Forms for financial documentation</li>
                <li>• Designed and developed BAPIs and RFC-enabled function modules</li>
                <li>• Conducted unit testing and integration testing ensuring zero production defects</li>
              </ul>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Tech Stack</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">SAP Platform</h3>
                <p className="text-sm text-muted-foreground">SAP ECC 6.0, S/4HANA, SAP ABAP NetWeaver 7.5</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Development</h3>
                <p className="text-sm text-muted-foreground">ABAP Objects, CDS Views, AMDP, BAPIs</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">UI/UX</h3>
                <p className="text-sm text-muted-foreground">SAP Fiori, OData Services, Gateway</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Database</h3>
                <p className="text-sm text-muted-foreground">SAP HANA, HANA SQL, AMDP</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Reporting</h3>
                <p className="text-sm text-muted-foreground">ALV, SmartForms, Adobe Forms</p>
              </div>
              <div className="bg-card p-4 rounded-lg border border-border">
                <h3 className="font-semibold mb-2 text-accent">Integration</h3>
                <p className="text-sm text-muted-foreground">RFC, IDocs, PI/PO, OData</p>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Process & Methods</h2>
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold mb-2">1. Requirements Analysis & Design</h3>
                <p className="text-foreground/90">
                  Collaborated with functional consultants and business stakeholders to gather requirements. Created 
                  technical specifications and design documents following SAP development standards.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">2. Development & Optimization</h3>
                <p className="text-foreground/90">
                  Developed ABAP objects using modern techniques like CDS Views for data modeling and AMDP for 
                  database-level processing. Optimized code for performance using HANA-specific features.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">3. Integration Implementation</h3>
                <p className="text-foreground/90">
                  Created OData services for Fiori applications and third-party system integrations. Developed BAPIs 
                  and RFC modules for seamless data exchange between systems.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">4. Testing & Quality Assurance</h3>
                <p className="text-foreground/90">
                  Conducted comprehensive unit testing, integration testing, and user acceptance testing. Implemented 
                  automated testing frameworks where applicable to ensure code quality.
                </p>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Deliverables & Outcomes</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gradient-to-br from-accent/10 to-transparent p-6 rounded-lg border border-accent/50">
                <div className="text-3xl font-bold text-accent mb-2">60%</div>
                <p className="text-foreground/90">Reduction in manual processing time</p>
              </div>
              <div className="bg-gradient-to-br from-accent/10 to-transparent p-6 rounded-lg border border-accent/50">
                <div className="text-3xl font-bold text-accent mb-2">Zero</div>
                <p className="text-foreground/90">Production defects after go-live</p>
              </div>
              <div className="bg-gradient-to-br from-accent/10 to-transparent p-6 rounded-lg border border-accent/50">
                <div className="text-3xl font-bold text-accent mb-2">100%</div>
                <p className="text-foreground/90">Enhanced reporting accuracy</p>
              </div>
              <div className="bg-gradient-to-br from-accent/10 to-transparent p-6 rounded-lg border border-accent/50">
                <div className="text-3xl font-bold text-accent mb-2">Real-time</div>
                <p className="text-foreground/90">Financial data visibility achieved</p>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4 text-accent">Key Achievements</h2>
            <ul className="space-y-3 text-foreground/90">
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>Automated invoice processing workflow reducing processing time from 2 days to 2 hours</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>Developed custom Fiori applications for mobile financial reporting accessed by C-suite executives</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>Created reusable ABAP components adopted across multiple projects</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>Successfully migrated legacy reports to HANA-optimized CDS Views</span>
              </li>
            </ul>
          </section>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link to="/projects">
              <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
                View More Projects
              </Button>
            </Link>
            <Link to="/contact">
              <Button variant="outline" className="border-accent text-accent hover:bg-accent hover:text-accent-foreground">
                Discuss Your Project
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SapAbap;
